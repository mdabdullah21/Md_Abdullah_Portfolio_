MD. ABDULLAH PORTFOLIO
=======================

Structure follows the supplied landing-page template style:

/
├── index.html
└── assets/
    ├── css/
    │   ├── style.css
    │   └── style.scss
    ├── js/
    │   └── script.js
    ├── image/
    │   └── profile.jpg
    ├── fonts/
    └── webfonts/

Open index.html in a browser.

Portfolio and GitHub are intentionally not included as links because they were left blank.
